# Build Bronze Layer

Checkbox: No
Tasks: commit code in git repo