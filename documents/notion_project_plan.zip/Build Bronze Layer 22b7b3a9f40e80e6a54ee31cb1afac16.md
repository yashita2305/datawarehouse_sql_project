# Build Bronze Layer

Checkbox: No
Tasks: Draw data flow(Draw.io)