# DATA WAREHOUSE PROJECT

[Datawarehouse Epics](Datawarehouse%20Epics%2022b7b3a9f40e80679acbf7965612057d.csv)

[DWH Tasks](DWH%20Tasks%2022b7b3a9f40e80b88cdffa12cad7ac22.csv)

[Bronze Line](Bronze%20Line%2022b7b3a9f40e802697fecb0d188404fb.csv)

[BUILD SILVER LAYER ](BUILD%20SILVER%20LAYER%2022b7b3a9f40e80f3b822f71251aa732c.csv)

[BUILD GOLD LAYER](BUILD%20GOLD%20LAYER%2022b7b3a9f40e807a843ddaf4ef76922f.csv)

1. Click `+ Add property` to add Status and Date columns
2. Click `+ New page` to add a new to do item and write a task
3. Set status to `Done` with today's date
4. Explore features: ‣ [filter](https://www.notion.com/help/views-filters-and-sorts#filters), ‣ [sort](https://www.notion.com/help/views-filters-and-sorts#sorts), and try different [views](https://www.notion.com/help/views-filters-and-sorts#create-and-switch-between-views)

<aside>
🎉

**Congratulations! You've just created your first Notion database.**

Need more? Type `/database` anywhere to create new databases for any purpose.

</aside>

- ***P.S.** Every item (row) is its own page*
    
    Hover over any row and click `◨ OPEN` to view that page and add more information in the form of text, images, and more. [Learn more here.](https://www.notion.com/help/intro-to-databases)