# Analyse and understand the requirements

Checkbox: Yes
Datawarehouse Epics: Requirement Analysis (Requirement%20Analysis%2022b7b3a9f40e80c3b4bdc7198722b64c.md)
Task Description: Objective
Develop SQL-based analytics to deliver detailed insights into:
• Customer Behavior
• Product Performance
• Sales Trends
Text: BI: Analytics and reporting