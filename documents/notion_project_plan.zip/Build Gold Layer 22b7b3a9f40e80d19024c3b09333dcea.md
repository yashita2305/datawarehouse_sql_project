# Build Gold Layer

Checkbox: Yes
Text: Document: Create Data Catalog