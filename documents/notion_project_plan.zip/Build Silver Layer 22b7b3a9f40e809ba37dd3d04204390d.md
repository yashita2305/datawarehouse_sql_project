# Build Silver Layer

Checkbox: Yes
Tasks: Document: Draw data integration