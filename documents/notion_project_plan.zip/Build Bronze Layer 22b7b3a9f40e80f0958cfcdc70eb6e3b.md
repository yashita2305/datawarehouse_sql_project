# Build Bronze Layer

Checkbox: No
Tasks: Validating : Data completeness and schema checks