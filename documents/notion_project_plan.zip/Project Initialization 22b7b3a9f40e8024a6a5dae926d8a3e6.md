# Project Initialization

DWH Tasks: Create Git repo and Prepare the structure (Create%20Git%20repo%20and%20Prepare%20the%20structure%2022b7b3a9f40e8055b053ece7df088be9.md), Create DB and Schemas (Create%20DB%20and%20Schemas%2022b7b3a9f40e809d94fecfb284a8c9c0.md), Create detailed Project tasks (Create%20detailed%20Project%20tasks%2022b7b3a9f40e804fa8aadf3a99fae89c.md), Define project naming conventions (Define%20project%20naming%20conventions%2022b7b3a9f40e802d9edee1a44b8dd775.md)
Progress: 1