# Build Silver Layer

Checkbox: Yes
Tasks: Coding : Data Cleaning