# Brainstorm and design the layers

Checkbox: Yes
Datawarehouse Epics: Project Data Architecture  (Project%20Data%20Architecture%2022b7b3a9f40e80bd9f2eea9d9a644291.md)