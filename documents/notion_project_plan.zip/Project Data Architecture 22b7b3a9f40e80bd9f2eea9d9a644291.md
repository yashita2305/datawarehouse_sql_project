# Project Data Architecture

DWH Tasks: choose data management approach (choose%20data%20management%20approach%2022b7b3a9f40e8011a8bfc67af78bdb54.md), Brainstorm and design the layers  (Brainstorm%20and%20design%20the%20layers%2022b7b3a9f40e8098867ef9ee98471906.md), Design the layers (Design%20the%20layers%2022b7b3a9f40e80cc847fdf1ae3372bd3.md), Draw the data architeture Draw.io) (Draw%20the%20data%20architeture%20Draw%20io)%2022b7b3a9f40e8063b176f091ed809619.md)
Progress: 1