# Build Gold Layer

Checkbox: Yes
Text: Analyzing : Explore Business Objects