# Build Gold Layer

Checkbox: Yes
Text: Document: Extend Data Flow (Draw.io)