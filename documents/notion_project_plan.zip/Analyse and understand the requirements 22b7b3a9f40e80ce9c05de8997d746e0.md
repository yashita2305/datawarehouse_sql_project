# Analyse and understand the requirements

Checkbox: Yes
Datawarehouse Epics: Requirement Analysis (Requirement%20Analysis%2022b7b3a9f40e80c3b4bdc7198722b64c.md)
Task Description: Objective: Develop a moder data warehouse using MySql to consolidate sales data enabling analytical reporting and informed decesion making.
Text: Building the Data Warehouse