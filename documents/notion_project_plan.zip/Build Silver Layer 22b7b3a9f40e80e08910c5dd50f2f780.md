# Build Silver Layer

Checkbox: Yes
Tasks: Analyzing : explore and understand data