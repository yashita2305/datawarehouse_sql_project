# Build Gold Layer

Checkbox: Yes
Text: Document: Draw Data Model For a Star Schema