# Define project naming conventions

Checkbox: Yes
Datawarehouse Epics: Project Initialization (Project%20Initialization%2022b7b3a9f40e8024a6a5dae926d8a3e6.md)