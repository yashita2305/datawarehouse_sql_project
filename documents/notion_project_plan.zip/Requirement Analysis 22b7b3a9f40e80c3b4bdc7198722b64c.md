# Requirement Analysis

DWH Tasks: Analyse and understand the requirements  (Analyse%20and%20understand%20the%20requirements%2022b7b3a9f40e80ce9c05de8997d746e0.md), Analyse and understand the requirements (Analyse%20and%20understand%20the%20requirements%2022b7b3a9f40e8026a49fde0e6a4fe4d9.md), Analyse and understand the requirements (Analyse%20and%20understand%20the%20requirements%2022b7b3a9f40e80bca19fea6ec7c8cb68.md)
Progress: 1