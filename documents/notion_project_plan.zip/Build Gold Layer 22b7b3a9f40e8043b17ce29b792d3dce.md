# Build Gold Layer

Checkbox: Yes
Text: Coding : Data Integration