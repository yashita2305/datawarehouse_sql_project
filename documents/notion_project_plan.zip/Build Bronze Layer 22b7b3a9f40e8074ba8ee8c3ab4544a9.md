# Build Bronze Layer

Checkbox: No
Tasks: Analyzing source systems