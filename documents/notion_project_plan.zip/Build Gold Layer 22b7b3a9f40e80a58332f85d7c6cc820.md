# Build Gold Layer

Checkbox: Yes
Text: Validating: Data Integration Checks