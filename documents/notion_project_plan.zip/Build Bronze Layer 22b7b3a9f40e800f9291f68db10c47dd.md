# Build Bronze Layer

Checkbox: No
Tasks: Coding: data ingestion